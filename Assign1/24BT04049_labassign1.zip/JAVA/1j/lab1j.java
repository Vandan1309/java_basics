class lab1j
{
public static void main(String args[]){
int i;
String string1="Hello world";
int l=string1.length();
System.out.println(l);
int L=l/2;
String s=string1.substring(L);
System.out.println(s);
}
}


