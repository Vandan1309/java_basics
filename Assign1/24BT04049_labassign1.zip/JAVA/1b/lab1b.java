class lab1b{
public static void main(String args[]){

System.out.println("Hello World");
System.out.println("Welcome to the World of JAVA Programming");

}
}
