class lab1l{
public static void main(String args[]){

int i,j;
String string1="GSFCU";
char[] s=string1.toCharArray();
for(i=0;i<=4;i++){
for(j=0;j<=i;j++){
System.out.print(s[j]);
}
System.out.println("");
}
}
}
